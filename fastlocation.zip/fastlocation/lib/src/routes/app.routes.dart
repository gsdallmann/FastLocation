class AppRoutes {
  static const String initial = '/';
  static const String home = '/home';
  static const String history = '/history';
}