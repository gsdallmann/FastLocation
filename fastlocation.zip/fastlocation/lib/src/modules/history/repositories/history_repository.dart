import 'package:hive/hive.dart';
import '../../home/model/address_model.dart';

class HistoryRepository {
  final Box _box = Hive.box('addresses');

  List<Address> getHistory() {
    return _box.values.cast<Address>().toList();
  }

  void saveAddress(Address address) {
    _box.add(address);
  }
}