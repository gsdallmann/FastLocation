import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import '../controller/history_controller.dart';

class HistoryPage extends StatelessWidget {
  final HistoryController controller;

  const HistoryPage({Key? key, required this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    controller.loadHistory();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Histórico de Consultas'),
      ),
      body: Observer(
        builder: (_) {
          if (controller.history.isEmpty) {
            return const Center(child: Text('Nenhum histórico encontrado.'));
          }

          return ListView.builder(
            itemCount: controller.history.length,
            itemBuilder: (context, index) {
              final address = controller.history[index];
              return ListTile(
                title: Text(address.cep),
                subtitle: Text('${address.street}, ${address.city} - ${address.state}'),
              );
            },
          );
        },
      ),
    );
  }
}