import 'package:mobx/mobx.dart';
import '../repositories/history_repository.dart';
import '../../home/model/address_model.dart';

part 'history_controller.g.dart';

class HistoryController = _HistoryControllerBase with _$HistoryController;

abstract class _HistoryControllerBase with Store {
  final HistoryRepository _repository;

  _HistoryControllerBase(this._repository);

  @observable
  List<Address> history = [];

  @action
  void loadHistory() {
    history = _repository.getHistory();
  }
}