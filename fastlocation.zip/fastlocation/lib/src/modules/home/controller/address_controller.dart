import 'package:mobx/mobx.dart';
import '../repositories/address_repository.dart';
import '../model/address_model.dart';

part 'address_controller.g.dart';

class AddressController = _AddressControllerBase with _$AddressController;

abstract class _AddressControllerBase with Store {
  final AddressRepository _repository;

  _AddressControllerBase(this._repository);

  @observable
  Address? address;

  @observable
  bool isLoading = false;

  @observable
  String errorMessage = '';

  @action
  Future<void> searchAddressByCep(String cep) async {
    isLoading = true;
    address = await _repository.fetchAddressByCep(cep);
    isLoading = false;
    if (address == null) {
      errorMessage = 'Endereço não encontrado';
    }
  }
}