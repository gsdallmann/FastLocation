class AddressModel {
  final String logradouro;
  final String bairro;
  final String cidade;
  final String estado;

  AddressModel({
    required this.logradouro,
    required this.bairro,
    required this.cidade,
    required this.estado,
  });

  factory AddressModel.fromJson(Map<String, dynamic> json) {
    return AddressModel(
      logradouro: json['logradouro'] ?? '',
      bairro: json['bairro'] ?? '',
      cidade: json['localidade'] ?? '',
      estado: json['uf'] ?? '',
    );
  }
}