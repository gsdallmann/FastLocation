import 'package:flutter/material.dart';
import '../model/address_model.dart';

class AddressDisplay extends StatelessWidget {
  final Address? address;

  const AddressDisplay({Key? key, required this.address}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (address == null) {
      return const Text('Nenhum endereço encontrado');
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('CEP: ${address!.cep}'),
        Text('Rua: ${address!.street}'),
        Text('Bairro: ${address!.neighborhood}'),
        Text('Cidade: ${address!.city}'),
        Text('Estado: ${address!.state}'),
      ],
    );
  }
}