import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import '../controller/address_controller.dart';
import '../components/search_field.dart';
import '../components/address_display.dart';

class HomePage extends StatelessWidget {
  final AddressController controller;

  HomePage({Key? key, required this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final searchController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text('FastLocation'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            SearchField(
              controller: searchController,
              onSearch: () => controller.searchAddressByCep(searchController.text),
            ),
            const SizedBox(height: 20),
            Observer(
              builder: (_) {
                if (controller.isLoading) {
                  return const CircularProgressIndicator();
                }

                if (controller.errorMessage.isNotEmpty) {
                  return Text(controller.errorMessage, style: const TextStyle(color: Colors.red));
                }

                return AddressDisplay(address: controller.address);
              },
            ),
          ],
        ),
      ),
    );
  }
}