import 'package:dio/dio.dart';
import '../model/address_model.dart';

class AddressRepository {
  final Dio _dio;

  AddressRepository(this._dio);

  Future<Address?> fetchAddressByCep(String cep) async {
    final response = await _dio.get('$cep/json/');
    if (response.statusCode == 200) {
      return Address.fromJson(response.data);
    }
    return null;
  }
}