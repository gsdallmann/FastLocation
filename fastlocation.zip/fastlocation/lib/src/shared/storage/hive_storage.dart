import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';

class HiveStorage {
  static const String _boxName = 'addresses';

  Future<void> init() async {
    final directory = await getApplicationDocumentsDirectory();
    Hive.init(directory.path);
    await Hive.openBox(_boxName);
  }

  Future<void> saveAddress(String address) async {
    final box = Hive.box(_boxName);
    await box.add(address);
  }

  List<String> getAddresses() {
    final box = Hive.box(_boxName);
    return box.values.cast<String>().toList();
  }
}