import 'package:dio/dio.dart';

class HttpService {
  final Dio dio;

  HttpService({Dio? dio})
      : dio = dio ?? Dio(BaseOptions(baseUrl: 'https://viacep.com.br/ws'));

  Future<Response> get(String path) async {
    try {
      final response = await dio.get(path);
      return response;
    } catch (error) {
      throw Exception('Erro ao realizar a requisição: $error');
    }
  }