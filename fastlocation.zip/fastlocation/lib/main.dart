mport 'package:flutter/material.dart';
import 'src/modules/initial/page/initial_page.dart';
import 'src/modules/home/page/home_page.dart';
import 'src/modules/history/page/history_page.dart';
import 'src/routes/app_routes.dart';
import 'src/http/http_service.dart';
import 'src/modules/home/repositories/address_repository.dart';
import 'src/modules/home/controller/address_controller.dart';
import 'src/modules/history/repositories/history_repository.dart';
import 'src/modules/history/controller/history_controller.dart';

void main() {
  runApp(const FastLocationApp());
}

class FastLocationApp extends StatelessWidget {
  const FastLocationApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FastLocation',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: AppRoutes.initial,
      routes: {
        AppRoutes.initial: (context) => const InitialPage(),
        AppRoutes.home: (context) {
          final httpService = HttpService();
          final addressRepository = AddressRepository(httpService);
          final addressController = AddressController(addressRepository);
          return HomePage(controller: addressController);
        },
        AppRoutes.history: (context) {
          final historyRepository = HistoryRepository();
          final historyController = HistoryController(historyRepository);
          return HistoryPage(controller: historyController);
        },
      },
    );
  }
}