package com.example.fastlocation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
